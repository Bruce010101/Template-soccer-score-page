
$(document).ready(function(){
  $('#slideshow .slick').slick({
    autoplay:true,
    autoplaySpeed: 1500,
    arrows:false,
    slidesToShow:1,
    slidesToScroll: 1,
    centerMode: false
  });
});


$(document).ready(function(){
  $('#slideshow-1 .slick').slick({
    autoplay:false,
    autoplaySpeed: 2500,
    arrows:true,
    slidesToShow:1,
    slidesToScroll: 1,
    centerMode: false

  });
});

$(document).ready(function(){
  $('#slideshow-2 .slick').slick({
    autoplay:true,
    autoplaySpeed: 2500,
    arrows:false,
    slidesToShow:1,
    slidesToScroll: 1,
    centerMode: false

  });
});



$(document).ready(function(){
  $('#slideshow-3 .slick').slick({
    autoplay:true,
    autoplaySpeed: 2500,
    arrows:false,
    slidesToShow:1,
    slidesToScroll: 1,
    centerMode: false

  });
});



$(document).ready(function(){
  $('#slideshow-4 .slick').slick({
   slidesToShow: 1,
   slidesToScroll: 1,
   arrows: false,
   fade: true,
   asNavFor: '.slider-nav'
  });
  $('.slider-nav').slick({
   slidesToShow: 3,
   slidesToScroll: 1,
   asNavFor: '.slick',
   dots: true,
   centerMode: true,
   focusOnSelect: true
  });
});
